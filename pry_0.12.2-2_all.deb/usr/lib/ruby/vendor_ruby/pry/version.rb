class Pry
  VERSION = '0.12.2'.freeze
end
